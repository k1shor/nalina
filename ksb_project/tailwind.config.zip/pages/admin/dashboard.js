import React from 'react'

const dashboard = () => {

    return (
        <>
            <p>Welcome to dashboard</p>


        </>
    )
}

export default dashboard