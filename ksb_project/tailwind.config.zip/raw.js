export const Clients = [
    {
        "id": 1,
        "name": "Sipradi Trading Pvt. Ltd.",
        "image": '/sipradi.jpg'
    },
    {
        "id": 2,
        "name": "Gokarna Forest Resort",
        "image": '/gokarna.jpg'
    },
    {
        "id": 3,
        "name": "Radisson Hotel",
        "image": '/raddition.jpg'

    },
    {
        "id": 2,
        "name": "Chandragiri Hills Resort",
        "image": '/chandragire.jpg'

    },
    {
        "id": 2,
        "name": "Hotel Del' Annapurna",
        "image": '/annapurna.jpg'

    },
    {
        "id": 2,
        "name": "Soaltee Crown Plaza",
        "image": '/soltae.jpg'

    },
    {
        "id": 2,
        "name": "Hotel Shangri-La",
        "image": '/sangrila-1.jpg'

    },
    {
        "id": 2,
        "name": "Shahid Gangalal Heart Center",
        "image": '/gangalal.jpg'

    },
]